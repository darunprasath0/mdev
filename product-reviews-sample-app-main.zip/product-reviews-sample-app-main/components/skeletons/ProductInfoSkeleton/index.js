export { ProductInfoSkeleton } from "./ProductInfoSkeleton";
